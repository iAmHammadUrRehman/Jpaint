package controller;

public interface IJPaintController {
    void setup();
}

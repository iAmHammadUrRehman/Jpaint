package controller.commands;

import static org.junit.jupiter.api.Assertions.*;

class CommandFactoryTest {

    @org.junit.jupiter.api.BeforeEach
    void setUp() {
    }

    @org.junit.jupiter.api.AfterEach
    void tearDown() {
    }

    @org.junit.jupiter.api.Test
    void drawCommand() {
    }

    @org.junit.jupiter.api.Test
    void selectCommand() {
    }

    @org.junit.jupiter.api.Test
    void moveCommand() {
    }
}
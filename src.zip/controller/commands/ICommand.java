package controller.commands;

public interface ICommand {

    void run();
}

package controller.commands;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class CommandHistoryTest {

    @Test
    void add() {
    }

    @Test
    void undo() {
    }

    @Test
    void redo() {
    }

    @Test
    void topUndoCommand() {
    }

    @Test
    void topRedoCommand() {
    }
}
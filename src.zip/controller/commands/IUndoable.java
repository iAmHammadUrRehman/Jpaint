package controller.commands;

public interface IUndoable {
    void undo();

    void redo();
}

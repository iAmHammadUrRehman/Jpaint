package model.shapeManipulation;

import java.awt.*;

public interface IShapeDrawer {

    void draw(CreateShape shape, Graphics2D graphics2d);
}

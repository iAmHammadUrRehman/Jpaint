package model.shapeManipulation;

public interface IShape_Observer {
    void update();
}
